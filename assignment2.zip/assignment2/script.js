$(document).ready(function() {
    // Handle form submission
    $('#feedbackForm').submit(function(event) {
      event.preventDefault(); // Prevent form from submitting normally
  
      // Get form data
      var formData = {
        name: $('#name').val(),
        email: $('#email').val(),
        message: $('#message').val()
      };
  
      // Validate name field
      if (formData.name.length < 3) {
        alert('Name must have at least 3 characters.');
        return; // Stop form submission if validation fails
      }
  
      // Validate message field
      if (formData.message.length > 200) {
        alert('Message must not exceed 200 characters.');
        return; // Stop form submission if validation fails
      }
  
      // Display form data in alert
      var alertMessage = 'Name: ' + formData.name + '\n' +
                         'Email: ' + formData.email + '\n' +
                         'Message: ' + formData.message;
      alert(alertMessage);
  
      // Clear form fields
      $('#feedbackForm')[0].reset();
    });
  
//     // Handle character counting
    $('#message').on('input', function() {
      var maxLength = 200;
      var currentLength = $(this).val().length;
      var remainingLength = maxLength - currentLength;
  
      // Update character count
      $('#charCount').text(remainingLength);
    });
document.addEventListener('DOMContentLoaded', function() {
    var textarea = document.getElementById('message');
    var charCount = document.getElementById('charCount');
    var maxLength = 200;
  
    textarea.addEventListener('input', function() {
      var currentLength = textarea.value.length;
      var remainingLength = maxLength - currentLength;
  
      charCount.textContent = remainingLength;
  
      if (currentLength >= maxLength) {
        textarea.value = textarea.value.substring(0, maxLength);
        textarea.setAttribute('readonly', 'readonly');
      } else {
        textarea.removeAttribute('readonly');
      }
    });
  });
  
  });
